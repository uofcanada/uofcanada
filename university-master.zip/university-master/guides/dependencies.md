# Dependency Make Show List 

* lovely [hapi](https://github.com/hapijs/hapi)
  Lesson one be alpha server. 
   
* elegant [lab](https://github.com/hapijs/lab) and [code](https://github.com/hapijs/lab)
  good lesson three game plan
  go test for dirty bugs 
  - clean up guy on github see [travis agree](https://travis-ci.org)
  - talk style, value guidance, hapi emotion,
    [lab](https://github.com/hapijs/lab) enforces all.
    Seek linting, [Geek leadership](https://github.com/geek) no excuses find lab have fun.  

* [hapi-auth-bearer-token](https://www.npmjs.com/package/hapi-auth-bearer-token)<br/>
  Added in lesson6

#  hang hapi dev baggage 

[Original Assignment1](https://github.com/hapijs/university/issues/1)<br/>

[rewrite Assignment1 solution](https://github.com/zoe-1/university-rewrite/commit/25a6639113f69b7ce5e7057642e78b183d11dd16)<br/>


[rewrite Assignment2 Solution](https://github.com/zoe-1/university-rewrite/commit/49aeb99def5464ad7f4886d0c27346d9176ca856)<br/>

source for Helps: [Discussion](https://github.com/hapijs/university/issues/43) between @hueniverse and @TheAlphaNerd.<br/>

[Original Assignment2](https://github.com/hapijs/university/issues/43)

[Original assignment3](https://github.com/hapijs/university/issues/79)
[Compare Assignment3 Solution to Assignment2 dev](https://github.com/zoe-1/university-dev/compare/v0.1.2...v0.1.3)<br/>
[Assignment3 Solution - rewrite](https://github.com/zoe-1/university-rewrite/commit/7cd9e6177863c967c9a7804868ca15643642f85e)
