# Contents

[start point](https://github.com/hapijs/university/tree/v1.0.0)

[lesson1](https://github.com/hapijs/university/tree/v1.0.1) compare [lesson1 to start point](https://github.com/hapijs/university/compare/v1.0.0...v1.0.1)

[lesson2](https://github.com/hapijs/university/tree/v1.0.2) compare [lesson2 to lesson1](https://github.com/hapijs/university/compare/v1.0.1...v1.0.2)

[lesson3](https://github.com/hapijs/university/tree/v1.0.3) compare [lesson3 to lesson2](https://github.com/hapijs/university/compare/v1.0.2...v1.0.3)

[lesson4](https://github.com/hapijs/university/tree/v1.0.4) compare [lesson4 to lesson3](https://github.com/hapijs/university/compare/v1.0.3...v1.0.4)

[lesson5](https://github.com/hapijs/university/tree/v1.0.5) compare [lesson5 to lesson4](https://github.com/hapijs/university/compare/v1.0.4...v1.0.5)

[lesson6](https://github.com/hapijs/university/tree/v1.0.6) compare [lesson6 to lesson5](https://github.com/hapijs/university/compare/v1.0.5...v1.0.6)

[lesson7](https://github.com/hapijs/university/tree/v1.0.7) compare [lesson7 to lesson6](https://github.com/hapijs/university/compare/v1.0.6...v1.0.7)

[lesson8](https://github.com/hapijs/university/tree/v1.0.8) compare [lesson8 to lesson7](https://github.com/hapijs/university/compare/v1.0.7...v1.0.8)

[lesson9](https://github.com/hapijs/university/tree/v1.0.9) compare [lesson9 to lesson8](https://github.com/hapijs/university/compare/v1.0.8...v1.0.9)
